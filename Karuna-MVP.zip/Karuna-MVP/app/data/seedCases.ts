// =====================================================================
// Karuna — seed cases for the demo
//
// 6 cases spanning the full life-cycle: reported → in treatment →
// discharged → adopted. Gives the NGO dashboard, donation page, and
// adoption page real-looking content the moment the app boots.
// =====================================================================

import { Case } from '../types';

// Small SVG-as-dataURL placeholders so the demo renders without external assets
const tile = (label: string, fill: string) =>
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 240">
      <rect width="320" height="240" fill="${fill}"/>
      <text x="50%" y="50%" font-family="sans-serif" font-size="22"
            fill="#fff" text-anchor="middle" dominant-baseline="middle">${label}</text>
    </svg>`,
  );

const isoDaysAgo = (d: number) =>
  new Date(Date.now() - d * 24 * 60 * 60 * 1000).toISOString();

export const SEED_CASES: Case[] = [
  {
    id: 'case_seed_001',
    createdAt: isoDaysAgo(0),
    reporterName: 'Aarav Sharma',
    reporterContact: '+91 98765 43210',
    imageDataUrl: tile('Injured dog · Labbipet', '#b45309'),
    location: { lat: 16.5062, lon: 80.6480, label: 'Labbipet, Vijayawada' },
    species: 'dog',
    injuryType: 'open_wound',
    severity: 'critical',
    probableCondition: 'Deep laceration on hind leg with early infection',
    firstAidSteps: [
      'Approach slowly and from the side.',
      'Pour clean water over wound for 30 seconds.',
      'Do NOT apply human ointment — wait for the responder.',
    ],
    status: 'reported',
    estimatedCostInr: 4500,
    donations: [],
    adoptionApplications: [],
    events: [
      { ts: isoDaysAgo(0), type: 'created', actor: 'Aarav Sharma', details: 'Case opened (critical)' },
    ],
    notes: [],
  },
  {
    id: 'case_seed_002',
    createdAt: isoDaysAgo(1),
    reporterName: 'Meera Iyer',
    imageDataUrl: tile('Stray dog · Benz Circle', '#1d4ed8'),
    location: { lat: 16.5093, lon: 80.6480, label: 'Benz Circle, Vijayawada' },
    species: 'dog',
    injuryType: 'fracture',
    severity: 'critical',
    probableCondition: 'Suspected fracture of right hind limb (RTA)',
    firstAidSteps: [
      'Do NOT try to set the limb.',
      'Slide a board under the animal as a stretcher.',
      'Cover with a light cloth to reduce shock.',
    ],
    status: 'in_treatment',
    assignedResponder: 'Volunteer R. Rao',
    ngo: 'Vijayawada Animal Care',
    estimatedCostInr: 7800,
    donations: [
      { id: 'don_seed_1', ts: isoDaysAgo(0.8), donorName: 'Priya N.', amountInr: 1500, message: 'Get well soon!' },
      { id: 'don_seed_2', ts: isoDaysAgo(0.4), donorName: 'Anonymous', amountInr: 2000 },
    ],
    adoptionApplications: [],
    events: [
      { ts: isoDaysAgo(1), type: 'created', actor: 'Meera Iyer', details: 'Case opened (critical)' },
      { ts: isoDaysAgo(0.95), type: 'assigned', actor: 'Vijayawada Animal Care', details: 'Dispatched to Volunteer R. Rao' },
      { ts: isoDaysAgo(0.9), type: 'status', actor: 'R. Rao', details: '→ collected' },
      { ts: isoDaysAgo(0.85), type: 'status', actor: 'Dr. Kavitha', details: '→ at_clinic' },
      { ts: isoDaysAgo(0.8), type: 'donation', actor: 'Priya N.', details: '₹1,500 donated' },
      { ts: isoDaysAgo(0.7), type: 'status', actor: 'Dr. Kavitha', details: '→ in_treatment' },
      { ts: isoDaysAgo(0.4), type: 'donation', actor: 'Anonymous', details: '₹2,000 donated' },
    ],
    notes: ['X-ray confirms tibial fracture. External fixation done.'],
  },
  {
    id: 'case_seed_003',
    createdAt: isoDaysAgo(3),
    reporterName: 'Karthik R.',
    imageDataUrl: tile('Cat with eye injury · Patamata', '#9333ea'),
    location: { lat: 16.5042, lon: 80.6571, label: 'Patamata, Vijayawada' },
    species: 'cat',
    injuryType: 'eye_injury',
    severity: 'urgent',
    probableCondition: 'Conjunctival swelling — possible foreign body',
    firstAidSteps: [
      'Do not touch the eye.',
      'Keep cat in dim, quiet room.',
      'Wait for the responder.',
    ],
    status: 'discharged',
    assignedResponder: 'Volunteer N. Lakshmi',
    ngo: 'Vijayawada Animal Care',
    estimatedCostInr: 2200,
    donations: [
      { id: 'don_seed_3', ts: isoDaysAgo(2.5), donorName: 'Rohit B.', amountInr: 1000 },
      { id: 'don_seed_4', ts: isoDaysAgo(2.0), donorName: 'Sneha M.', amountInr: 1200 },
    ],
    adoptionApplications: [],
    events: [
      { ts: isoDaysAgo(3), type: 'created', actor: 'Karthik R.', details: 'Case opened (urgent)' },
      { ts: isoDaysAgo(2.9), type: 'assigned', actor: 'Vijayawada Animal Care', details: 'Dispatched to N. Lakshmi' },
      { ts: isoDaysAgo(2.8), type: 'status', actor: 'N. Lakshmi', details: '→ collected' },
      { ts: isoDaysAgo(2.7), type: 'status', actor: 'Dr. Suresh', details: '→ at_clinic' },
      { ts: isoDaysAgo(2.5), type: 'donation', actor: 'Rohit B.', details: '₹1,000 donated' },
      { ts: isoDaysAgo(2.5), type: 'status', actor: 'Dr. Suresh', details: '→ in_treatment' },
      { ts: isoDaysAgo(2.0), type: 'donation', actor: 'Sneha M.', details: '₹1,200 donated' },
      { ts: isoDaysAgo(1.0), type: 'status', actor: 'Dr. Suresh', details: '→ discharged' },
    ],
    notes: ['Foreign body removed; cat is recovering well, eligible for adoption.'],
  },
  {
    id: 'case_seed_004',
    createdAt: isoDaysAgo(5),
    reporterName: 'Anjali D.',
    imageDataUrl: tile('Puppy · mange · Gunadala', '#059669'),
    location: { lat: 16.5260, lon: 80.6608, label: 'Gunadala, Vijayawada' },
    species: 'dog',
    injuryType: 'mange',
    severity: 'routine',
    probableCondition: 'Sarcoptic mange across back and tail — treatable',
    firstAidSteps: [
      'Do not touch with bare hands.',
      'Offer water and soft food.',
      'Keep away from pet animals.',
    ],
    status: 'discharged',
    assignedResponder: 'Volunteer K. Suri',
    ngo: 'Karuna Volunteers',
    estimatedCostInr: 1500,
    donations: [
      { id: 'don_seed_5', ts: isoDaysAgo(4.5), donorName: 'Anonymous', amountInr: 500 },
      { id: 'don_seed_6', ts: isoDaysAgo(4.0), donorName: 'Mira P.', amountInr: 1000 },
    ],
    adoptionApplications: [
      {
        id: 'app_seed_1',
        ts: isoDaysAgo(0.5),
        applicantName: 'Ramesh K.',
        contact: 'ramesh.k@example.com',
        reason: 'I have a small house with a yard and have raised dogs before.',
        status: 'pending',
      },
    ],
    events: [
      { ts: isoDaysAgo(5), type: 'created', actor: 'Anjali D.', details: 'Case opened (routine)' },
      { ts: isoDaysAgo(4.8), type: 'status', actor: 'K. Suri', details: '→ collected' },
      { ts: isoDaysAgo(4.5), type: 'donation', actor: 'Anonymous', details: '₹500 donated' },
      { ts: isoDaysAgo(4.0), type: 'donation', actor: 'Mira P.', details: '₹1,000 donated' },
      { ts: isoDaysAgo(2.0), type: 'status', actor: 'Dr. Kavitha', details: '→ discharged' },
      { ts: isoDaysAgo(0.5), type: 'adoption_application', actor: 'Ramesh K.', details: 'Applied to adopt' },
    ],
    notes: ['Three-week ivermectin cycle completed. Puppy is healthy.'],
  },
  {
    id: 'case_seed_005',
    createdAt: isoDaysAgo(10),
    reporterName: 'Sai Prasad',
    imageDataUrl: tile('Rescued dog · adopted', '#dc2626'),
    location: { lat: 16.5152, lon: 80.6321, label: 'Governorpet, Vijayawada' },
    species: 'dog',
    injuryType: 'bleeding',
    severity: 'critical',
    probableCondition: 'Head wound from a fall — stitched and recovered',
    firstAidSteps: [],
    status: 'adopted',
    assignedResponder: 'Volunteer A. Krishna',
    ngo: 'Vijayawada Animal Care',
    estimatedCostInr: 3500,
    donations: [
      { id: 'don_seed_7', ts: isoDaysAgo(9), donorName: 'Karuna Donors Pool', amountInr: 3500, message: 'Full coverage' },
    ],
    adoptionApplications: [
      {
        id: 'app_seed_2',
        ts: isoDaysAgo(2),
        applicantName: 'Vidya & Suresh',
        contact: 'vidya@example.com',
        reason: 'We lost our previous pet last year and would love to give this dog a home.',
        status: 'approved',
      },
    ],
    events: [
      { ts: isoDaysAgo(10), type: 'created', actor: 'Sai Prasad', details: 'Case opened (critical)' },
      { ts: isoDaysAgo(9), type: 'donation', actor: 'Karuna Donors Pool', details: '₹3,500 donated' },
      { ts: isoDaysAgo(8), type: 'status', actor: 'Dr. Kavitha', details: '→ in_treatment' },
      { ts: isoDaysAgo(5), type: 'status', actor: 'Dr. Kavitha', details: '→ discharged' },
      { ts: isoDaysAgo(2), type: 'adoption_application', actor: 'Vidya & Suresh', details: 'Applied to adopt' },
      { ts: isoDaysAgo(1), type: 'adoption_decision', actor: 'NGO Admin', details: 'Adoption application approved (Vidya & Suresh)' },
    ],
    notes: ['Wonderful adoption. Post-placement check-in scheduled at 2 weeks.'],
  },
  {
    id: 'case_seed_006',
    createdAt: isoDaysAgo(2),
    reporterName: 'Lakshmi S.',
    imageDataUrl: tile('Cow · roadside · Tanuku', '#9a3412'),
    location: { lat: 16.7531, lon: 81.6818, label: 'Tanuku, West Godavari' },
    species: 'cow',
    injuryType: 'open_wound',
    severity: 'urgent',
    probableCondition: 'Wound on flank, possibly from a nail',
    firstAidSteps: [
      'Keep distance — cow may be stressed.',
      'Mark location with a stone/cloth.',
      'Wait for the responder.',
    ],
    status: 'assigned',
    assignedResponder: 'Volunteer M. Reddy',
    ngo: 'Karuna Volunteers',
    estimatedCostInr: 5200,
    donations: [
      { id: 'don_seed_8', ts: isoDaysAgo(1.5), donorName: 'Ravi V.', amountInr: 700 },
    ],
    adoptionApplications: [],
    events: [
      { ts: isoDaysAgo(2), type: 'created', actor: 'Lakshmi S.', details: 'Case opened (urgent)' },
      { ts: isoDaysAgo(1.8), type: 'assigned', actor: 'Karuna Volunteers', details: 'Dispatched to M. Reddy' },
      { ts: isoDaysAgo(1.5), type: 'donation', actor: 'Ravi V.', details: '₹700 donated' },
    ],
    notes: [],
  },
];
